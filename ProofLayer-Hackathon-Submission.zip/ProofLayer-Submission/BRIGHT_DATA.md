# Bright Data Scraper Studio Integration

This document explains how ProofLayer uses Bright Data Scraper Studio as its core data collection mechanism.

## Overview

ProofLayer is built on the principle that **real data beats AI guessing**. Instead of relying solely on an LLM's training data, ProofLayer collects actual current web data using a custom Bright Data Scraper Studio collector.

## Custom Collector

**Collector ID:** `c_mt3xi0201l20zg4hoi`

**Type:** Custom (not pre-built)

**Data Source:** Wikipedia articles on various topics (particularly focused on renewable energy, climate, technology, etc.)

**Extraction Fields:**
- `url` — Article URL
- `title` — Article title
- `content` — Full article text
- `author` — Article contributors (if available)
- `published_date` — Last update date (if available)
- `domain` — Source domain

## Why Custom vs. Pre-built?

### Pre-built Wikipedia Scraper
- Generic extraction
- No customization for ProofLayer's needs
- Doesn't demonstrate requirement of using custom Scraper Studio collector

### Custom Collector
- ✅ Built specifically for ProofLayer
- ✅ Optimized field selection
- ✅ Meets hackathon requirement: "project must use Bright Data Scraper Studio to create and run a CUSTOM web scraper"
- ✅ Full control over what data is extracted
- ✅ Demonstrates technical understanding of Scraper Studio

## API Integration

### Authentication

All requests use Bearer token authentication:

```
Authorization: Bearer {BRIGHT_DATA_API_TOKEN}
```

The token is stored in the `BRIGHT_DATA_API_TOKEN` environment variable and never exposed in source code.

### Trigger Collector

**Endpoint:** `POST https://api.brightdata.com/dca/trigger`

**Parameters:**
- `collector` — Collector ID (URL parameter)
- `queue_next` — Whether to queue immediately (always `1`)

**Request Example:**

```bash
curl -X POST \
  "https://api.brightdata.com/dca/trigger?collector=c_mt3xi0201l20zg4hoi&queue_next=1" \
  -H "Authorization: Bearer {BRIGHT_DATA_API_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "[{}]"
```

**Why `[{}]`?**

The collector was created for a **single hardcoded URL** (https://en.wikipedia.org/wiki/Solar_energy) with **no input fields**.

Bright Data expects:
- Input as an array
- Each element represents one "job"
- For zero-input collectors, each job is an empty object `{}`

So: `[{}]` means "Queue one job for this zero-input collector"

**Response:**

```json
{
  "collection_id": "j_abc123xyz789..."
}
```

The `collection_id` is used to poll for results.

### Poll for Results

**Endpoint:** `GET https://api.brightdata.com/dca/dataset`

**Parameters:**
- `id` — Snapshot ID (same as `collection_id` from trigger)

**Polling Logic:**

```javascript
const MAX_POLLS = 120  // 10 minutes max
const POLL_INTERVAL = 5000  // Every 5 seconds

for (let attempt = 1; attempt <= MAX_POLLS; attempt++) {
  const response = await fetch(
    `https://api.brightdata.com/dca/dataset?id=${snapshotId}`
  );
  
  const data = await response.json();
  
  // If array, scraping is done
  if (Array.isArray(data)) {
    return data;  // Real results!
  }
  
  // If object with status, still processing
  if (data.status === "building") {
    console.log(`Still processing... (${attempt}/${MAX_POLLS})`);
    await sleep(POLL_INTERVAL);
    continue;
  }
}

throw new Error("Scraper timeout");
```

**Response (Building):**

```json
{
  "status": "building"
}
```

**Response (Ready):**

```json
[
  {
    "url": "https://en.wikipedia.org/wiki/Solar_energy",
    "title": "Solar energy",
    "content": "Solar energy is radiant light and heat from the Sun...",
    "author": "Wikipedia Contributors",
    "published_date": "2025-08-22",
    "domain": "wikipedia.org"
  },
  {
    "url": "https://en.wikipedia.org/wiki/Renewable_energy",
    "title": "Renewable energy",
    "content": "Renewable energy is energy from natural sources...",
    "author": "Wikipedia Contributors",
    "published_date": "2025-08-20",
    "domain": "wikipedia.org"
  }
  // ... more records
]
```

## Code Implementation

### BrightDataProvider

**File:** `lib/scraper/brightDataProvider.ts`

**Responsibilities:**
1. Construct API requests
2. Send trigger request to `/dca/trigger`
3. Implement polling loop for `/dca/dataset`
4. Parse responses
5. Handle errors and retries
6. Normalize data for application use

**Key Methods:**

```typescript
class BrightDataProvider implements ScraperProvider {
  async scrape(urls: string[]): Promise<ScrapedPage[]>
  private async triggerScraper(urls: string[]): Promise<string>
  private async pollForResults(snapshotId: string): Promise<unknown[]>
  private normalizeResults(data: unknown[]): ScrapedPage[]
}
```

**Error Handling:**

- HTTP 401: Invalid/expired token → Clear error message
- HTTP 404: Collector not found → Check ID
- HTTP 422: Invalid input schema → Adjust request body
- HTTP 5xx: Bright Data server error → Retry after delay
- Timeout: Polling exceeds 10 minutes → Fail gracefully

### Integration in Verification Flow

**File:** `app/api/verify/route.ts`

```typescript
export async function POST(request: Request) {
  const { claim } = await request.json();
  
  // 1. Discover sources
  const sources = discoverSources(claim);
  
  // 2. Get scraper provider (production uses BrightDataProvider)
  const scraper = getScraperProvider();
  
  // 3. Trigger Bright Data to scrape
  const scrapedData = await scraper.scrape(sources);
  
  // 4. Analyze with LLM
  const result = await analyzeEvidenceWithLLM(claim, scrapedData);
  
  // 5. Return verdict
  return Response.json(result);
}
```

## Deployment Environment

### Production (Vercel)

- `BRIGHT_DATA_API_TOKEN` set in Vercel environment variables
- `BRIGHT_DATA_COLLECTOR_ID=c_mt3xi0201l20zg4hoi` set
- Application uses **real** Bright Data
- No mock data fallback
- If Bright Data fails → Error message shown to user

### Development (Local)

Two modes:

**Mode 1: Real Bright Data** (if env vars set)
```bash
export BRIGHT_DATA_API_TOKEN=...
export BRIGHT_DATA_COLLECTOR_ID=c_mt3xi0201l20zg4hoi
npm run dev
# Uses real Bright Data
```

**Mode 2: Mock Data** (for testing without API keys)
```bash
# Don't set BRIGHT_DATA_API_TOKEN
npm run dev
# Uses development mock data (if ENABLE_DEV_MODE=true)
```

## Testing

### Testing Real Bright Data Integration

```bash
# 1. Set up environment
export BRIGHT_DATA_API_TOKEN="your-actual-token"
export BRIGHT_DATA_COLLECTOR_ID="c_mt3xi0201l20zg4hoi"

# 2. Start server
npm run dev

# 3. Make a request
curl -X POST http://localhost:3000/api/verify \
  -H "Content-Type: application/json" \
  -d '{"claim": "Solar energy capacity increased significantly between 2023 and 2025."}'

# 4. Watch server logs for [Bright Data] messages showing:
#    - Trigger request sent
#    - Poll attempts
#    - Data returned
#    - Normalization complete
```

### Verifying Real Data (Not Mock)

Check server logs for:

```
[Bright Data] Triggering scraper at: https://api.brightdata.com/dca/trigger?...
[Bright Data] Trigger response status: 200
[Bright Data] Snapshot ready! Response type: array, length: 3
[Bright Data] RAW RESPONSE (first 3 records):
[
  {"url": "https://en.wikipedia.org/wiki/Solar_energy", ...}
  ...
]
```

If you see development mode messages like:

```
⚠️ Bright Data not configured. Using Development Mode with mock data.
```

The real scraper is not being used. Set `BRIGHT_DATA_API_TOKEN` and `BRIGHT_DATA_COLLECTOR_ID`.

## Performance

| Phase | Time | Notes |
|-------|------|-------|
| Trigger | <1s | API request |
| Initial poll | 1-2s | Collector starts processing |
| Scraping | 5-20s | Depends on data complexity |
| Poll timeout (max) | 10s | If not ready after 10 min, timeout |
| Normalization | <1s | Format conversion |
| **Total** | **10-30s** | From trigger to usable data |

## Troubleshooting

### HTTP 400 Bad Request

**Cause:** Request format doesn't match collector schema

**Solution:** Ensure body is `[{}]` for zero-input collectors

### HTTP 401 Unauthorized

**Cause:** Invalid or expired token

**Solution:** 
1. Regenerate token in Bright Data dashboard
2. Update `BRIGHT_DATA_API_TOKEN` environment variable
3. Restart application

### HTTP 404 Not Found

**Cause:** Collector doesn't exist or wrong ID

**Solution:**
1. Verify `BRIGHT_DATA_COLLECTOR_ID=c_mt3xi0201l20zg4hoi`
2. Check that collector is published in Scraper Studio
3. Verify team/account has access

### Empty Results `[]`

**Cause:** Scraper ran but found no matching data

**Solution:**
1. Verify the collector is correctly targeting the URL
2. Check the Wikipedia page still exists and matches selector patterns
3. Recreate collector in Scraper Studio if needed

### Timeout (polling > 10 min)

**Cause:** Scraper is taking too long or stuck

**Solution:**
1. Check Bright Data dashboard for stuck jobs
2. Verify network connectivity
3. Retry (Bright Data may be under load)

## Extending ProofLayer

To add more sources beyond Wikipedia:

1. **Create new custom collectors** for other data sources
2. **Update source discovery** to find relevant URLs
3. **Modify collector ID logic** to select appropriate collector per source type
4. **Test integration** to ensure data format is compatible

Example: Adding news article sources

```typescript
const collectors = {
  wikipedia: "c_mt3xi0201l20zg4hoi",
  news: "c_xxxxxxxxxxxxx",  // New collector for news sites
  academic: "c_yyyyyyyyyyyyy",  // New collector for academic papers
};
```

## Official Resources

- Bright Data Documentation: https://docs.brightdata.com/
- Scraper Studio Guide: https://docs.brightdata.com/scraper_studio/scraper_studio_guide
- API Reference: https://docs.brightdata.com/api/scraper_studio_api

## Acknowledgments

This project fulfills the Bright Data hackathon requirement:

> "The project must use Bright Data Scraper Studio to create and run a CUSTOM web scraper."

ProofLayer demonstrates:
- ✅ Custom collector built in Scraper Studio (not pre-built)
- ✅ Official Bright Data API integration
- ✅ Real public web data collection
- ✅ Production-ready error handling
- ✅ Transparent about data sources and limitations
