# ProofLayer Demo Script

This script guides you through a live demonstration of ProofLayer at the Bright Data hackathon.

## Pre-Demo Setup (5 minutes before)

### 1. Verify Application is Running

```bash
# Terminal 1: Start the application
cd ProofLayer
npm run dev

# Output should show:
# ▲ Next.js 14.0.0
# - Local: http://localhost:3000
```

### 2. Verify Environment Variables Are Set

```bash
# Terminal 2: Check env vars are loaded
grep -E "BRIGHT_DATA|LLM_" .env.local

# Should show:
# BRIGHT_DATA_API_TOKEN=...
# BRIGHT_DATA_COLLECTOR_ID=c_mt3xi0201l20zg4hoi
# LLM_API_KEY=...
# LLM_MODEL=gpt-4-turbo
```

### 3. Open Two Browser Tabs

**Tab 1:** ProofLayer application
- URL: http://localhost:3000
- Keep claim input ready

**Tab 2:** DevTools Network/Console
- Open: http://localhost:3000
- Press F12 → Network tab
- Filter for: `api/verify` and `api.brightdata.com`

## Demo Flow (15 minutes)

### Slide 1: Problem Statement (2 min)

**Narration:**

"The internet has millions of answers, but how do we know what's true? 

Google gives you 50 results. Wikipedia might be biased. AI language models hallucinate.

Where's the evidence?

That's why we built ProofLayer."

**Visual:**
- Show a screenshot of Google search results (noisy)
- Show a screenshot of ChatGPT response (no sources)
- Show ProofLayer UI (clean, evidence-focused)

### Slide 2: The Solution (1 min)

**Narration:**

"ProofLayer doesn't just tell you what to believe. It collects real public web data, analyzes it, and shows you the evidence.

We use Bright Data Scraper Studio to collect actual current data from Wikipedia. Then we use AI to reason over that evidence.

Real data beats AI guessing."

**Visual:**
- Show the ProofLayer pipeline diagram
- Highlight: User → Bright Data → Real Data → LLM → Verdict

### Slide 3: Live Demo (12 min)

**Step 1: Enter a Claim (1 min)**

**Narration:**

"Let's test it. I'll enter a claim about solar energy."

**Action:**
- Click the claim input field
- Type: "Solar energy capacity increased significantly between 2023 and 2025."
- Show character counter
- Click "Verify Claim" button

**Expected UI:**
- Button changes to loading state
- Input field is disabled

---

**Step 2: Watch the Loading States (3 min)**

**Narration:**

"Now ProofLayer is working. Let me explain what's happening:

First, it's discovering relevant sources. It's looking for Wikipedia articles about renewable energy, solar power, and energy production.

Then it's using Bright Data to scrape those articles. This is live data collection—not AI hallucination.

While we wait, let me show you the network requests."

**Action:**
- Switch to **Tab 2: DevTools Network Tab**
- Show incoming requests to `/api/verify`
- Look for `api.brightdata.com` requests

**Expected in Network Tab:**
```
POST /api/verify
  → 200 OK
  
GET api.brightdata.com/dca/dataset?id=j_...
  → 200 OK (status: building)
  → 200 OK (status: building)
  → 200 OK (array response with data)
```

**In Console:**
```
[Bright Data] Triggering scraper at: https://api.brightdata.com/dca/trigger?...
[Bright Data] Trigger response status: 200
[Bright Data] Snapshot ready! Response type: array, length: 3
[Bright Data] RAW RESPONSE (first 3 records):
[{url: "https://en.wikipedia.org/wiki/Solar_energy", title: "Solar energy", ...}]
```

**Narration:**

"See? Real data from Bright Data. Not mock data. Not AI guessing. Actual Wikipedia articles scraped live.

The scraper gathered data from 3 Wikipedia articles. Now the LLM is analyzing this evidence."

---

**Step 3: Show Results (5 min)**

**Narration:**

"And here's the verdict."

**Action:**
- Switch back to **Tab 1: ProofLayer**
- Results should be displayed

**Expected Results:**

```
Verdict: SUPPORTED
Confidence: 82%

Explanation:
Multiple Wikipedia sources confirm that solar energy capacity 
expanded significantly from 2023 to 2025, growing from 
approximately 1.0 TW to 1.5 TW of installed capacity, 
representing the fastest-growing energy source globally.

Sources Analyzed: 3

Key Findings:
✓ Solar capacity grew from 1.0 TW to 1.5 TW
✓ Fastest-growing renewable energy source
✓ Growth driven by cost reduction and policy support
```

**Action:**
- Scroll down to show **Evidence Matrix**

**Expected:**
```
Source                      | Supports | Contradicts | Evidence
Solar energy (Wikipedia)    |    ✓     |             | Capacity 1.5 TW...
Renewable energy (Wikipedia)|    ✓     |             | Solar dominates...
Energy production (Wiki)    |    ✓     |             | 50% CAGR 2023...
```

**Action:**
- Click on one source card to expand details

**Expected:**
- Article title + URL
- Relevant excerpt showing how it relates to the claim
- Publication date
- Key facts extracted by LLM

**Narration:**

"Notice what we see here:

1. **Real Data** — This comes from Bright Data scraping Wikipedia live
2. **Evidence Trail** — You can see exactly which sources support the claim
3. **Confidence Score** — 82% means strong agreement across sources
4. **No Hallucinations** — Every claim is backed by actual source text

This is what separates ProofLayer from just asking ChatGPT."

---

### Slide 4: Technical Deep Dive (Optional, if time allows)

**Narration:**

"Let me show you how Bright Data is integrated."

**Action:**
- Switch to **Tab 2: DevTools Console**
- Run this command:

```javascript
// Simulate checking what Bright Data returned
const response = [
  {
    url: "https://en.wikipedia.org/wiki/Solar_energy",
    title: "Solar energy",
    content: "Solar energy is radiant light and heat from the Sun...",
    domain: "wikipedia.org"
  }
];

console.log("Bright Data returned:", response.length, "records");
console.log("Data:", response);
```

**Narration:**

"This is the actual structure of data coming from our Bright Data custom collector.

We created a custom Scraper Studio collector specifically for this project. It extracts:
- Article URLs
- Titles
- Full content
- Domain information

Then our backend normalizes this, sends it to the LLM with the user's claim, and out comes the verdict."

---

### Slide 5: Why This Matters (1 min)

**Narration:**

"Why does ProofLayer matter?

1. **Trustworthy** — Real data, not AI guessing
2. **Current** — Live web data, not training data from 2023
3. **Transparent** — You see exactly where information comes from
4. **Scalable** — Bright Data can scrape any website, in any language
5. **Verifiable** — Anyone can click the source links and verify

This is the future of fact-checking and evidence-based decision making."

---

## Advanced Demo (If Asked About Edge Cases)

### Test Case 1: Contradictory Sources

**Claim:** "AI has no limitations."

**Expected Verdict:** MIXED

**Narration:**

"When sources disagree, ProofLayer honestly shows that. Some sources discuss benefits, others mention limitations. The verdict reflects this nuance."

### Test Case 2: Insufficient Evidence

**Claim:** "The quantum computing breakthrough on March 15, 2026 in Uzbekistan was revolutionary."

**Expected Verdict:** INSUFFICIENT_EVIDENCE

**Narration:**

"ProofLayer doesn't hallucinate. When sources don't have relevant information, it says so. No false confidence."

### Test Case 3: Strong Contradiction

**Claim:** "Coal is the fastest-growing energy source."

**Expected Verdict:** CONTRADICTED

**Narration:**

"Wikipedia clearly shows renewable energy, not coal, is fastest-growing. ProofLayer catches this contradiction."

---

## Talking Points

### About Bright Data Integration

"We specifically built a custom Bright Data Scraper Studio collector. Not a pre-built one—that's a hackathon requirement.

Why? Because pre-built scrapers are one-size-fits-all. Our custom collector is optimized for extracting evidence-relevant content from Wikipedia articles.

The collector is triggered via the official Bright Data API:
- POST /dca/trigger to queue a job
- GET /dca/dataset to poll for results
- Response is real Wikipedia data

This isn't mock data. This is live collection from the public web."

### About the Tech Stack

"We used:
- **Frontend:** Next.js + React + Tailwind CSS
- **Backend:** Next.js API routes + TypeScript
- **Scraping:** Bright Data Scraper Studio (custom collector)
- **AI:** OpenAI GPT-4 Turbo for evidence analysis
- **Deployment:** Vercel

The whole thing is deployed on Vercel and working in production."

### About AI Tools Used

"We used AI coding assistants (Claude, ChatGPT, Grok) to accelerate development. But the team:
- Directed the architecture
- Configured Bright Data
- Fixed integration issues
- Tested everything
- Wrote documentation

We're transparent about AI usage because that's ethical."

---

## Troubleshooting During Demo

### Problem: Slow Response (> 30 seconds)

**Cause:** Bright Data might be processing

**Solution:**
- Show the Network tab polling results
- Explain: "Bright Data is scraping live data, this takes 10-30 seconds"
- While waiting, discuss architecture

### Problem: API Error

**Cause:** Token expired or network issue

**Solution:**
- Refresh environment variables
- Try a different claim
- Explain error handling: "If Bright Data fails, the app shows a clear error instead of hallucinating"

### Problem: LLM Timeout

**Cause:** OpenAI API slow or rate limited

**Solution:**
- Try a simpler claim
- Explain: "We have fallback error handling for this"

---

## Post-Demo Q&A

### Q: How is this different from just using ChatGPT?

**A:** 
"ChatGPT uses training data from 2023 and can hallucinate. ProofLayer scrapes live current data and shows you exactly which sources support the verdict. You can click the links and verify yourself."

### Q: Why Bright Data specifically?

**A:**
"Bright Data's Scraper Studio gives us:
1. Easy-to-use visual builder for creating custom scrapers
2. Official API that's well-documented
3. Reliable data collection at scale
4. This was the hackathon requirement

We could have used Selenium or Playwright, but Bright Data is production-ready."

### Q: How do you handle bias in sources?

**A:**
"Good question. Right now we use Wikipedia, which is reasonably neutral but not perfect. To extend ProofLayer, we'd:
1. Add more diverse sources (news, academic papers, government data)
2. Weight sources by credibility
3. Explicitly flag when sources disagree
4. Show source metadata so users can evaluate bias

This is what we'd build next."

### Q: Can you scale this to millions of users?

**A:**
"Yes. We'd need:
1. Caching layer (Redis) for source discovery
2. Database for claim history
3. Rate limiting on Bright Data
4. Batch processing for high volume
5. Horizontal scaling with Vercel Functions

Currently built for tens of users. Production scale would require infrastructure upgrades."

### Q: What about real-time claims (breaking news)?

**A:**
"Great point. Right now we use Wikipedia which updates slower. To handle breaking news, we'd:
1. Add news site collectors to Bright Data
2. Implement more aggressive caching strategy
3. Use LLM to weight recency

That's future work."

---

## Demo Video Recording (If Possible)

If recording for online submission:

```bash
# 1. Open screen recording software (OBS, ScreenFlow, etc.)
# 2. Record at 1080p 30fps
# 3. Follow the demo script above
# 4. Total time: ~10 minutes
# 5. Include audio narration
# 6. Upload to YouTube (unlisted or public)
```

**Demo video checklist:**
- ✓ Enter claim
- ✓ Show loading states
- ✓ Show network requests
- ✓ Display verdict
- ✓ Show evidence matrix
- ✓ Click source card
- ✓ Explain Bright Data integration
- ✓ Discuss why this approach is better

---

## Success Criteria

After the demo, judges should understand:

1. **What ProofLayer does** — Turns claims into evidence-backed verdicts
2. **Why it matters** — Real data beats AI guessing
3. **How Bright Data is used** — Custom collector for live data scraping
4. **Technical depth** — Next.js, TypeScript, proper API integration
5. **Why it's production-ready** — Deployed on Vercel, error handling, clear documentation

---

**Good luck with your demo! 🚀**
