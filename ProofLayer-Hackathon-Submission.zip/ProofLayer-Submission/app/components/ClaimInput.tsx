"use client";

import { useState } from "react";

interface ClaimInputProps {
  onSubmit: (claim: string) => void;
}

export default function ClaimInput({ onSubmit }: ClaimInputProps) {
  const [input, setInput] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (trimmed.length > 0) {
      onSubmit(trimmed);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white px-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">ProofLayer</h1>
          <p className="text-xl text-gray-600">Turn web claims into evidence.</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="mb-8">
          <div className="mb-6">
            <label htmlFor="claim" className="block text-sm font-semibold text-gray-700 mb-2">
              Enter a claim to verify
            </label>
            <textarea
              id="claim"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Example: Solar energy capacity increased significantly between 2023 and 2025."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              rows={3}
            />
            <p className="text-xs text-gray-500 mt-2">
              {input.length}/500 characters
            </p>
          </div>

          <button
            type="submit"
            disabled={input.trim().length === 0}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white font-semibold py-3 px-6 rounded-lg transition"
          >
            Verify Claim
          </button>
        </form>

        {/* Example claims */}
        <div className="border-t pt-8">
          <p className="text-sm font-semibold text-gray-700 mb-4">Example claims:</p>
          <div className="space-y-2">
            <div className="p-3 bg-gray-50 rounded text-sm text-gray-700">
              "Renewable energy is the fastest growing energy source globally."
            </div>
            <div className="p-3 bg-gray-50 rounded text-sm text-gray-700">
              "Artificial intelligence has improved language understanding capabilities."
            </div>
            <div className="p-3 bg-gray-50 rounded text-sm text-gray-700">
              "Global temperatures have increased over the past century."
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-12 text-center text-xs text-gray-500">
          <p>ProofLayer uses real public web data to analyze claims.</p>
          <p>No personal information is collected or used.</p>
        </div>
      </div>
    </div>
  );
}
