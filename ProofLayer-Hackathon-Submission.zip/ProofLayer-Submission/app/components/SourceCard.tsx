"use client";

import { Evidence } from "@/lib/evidenceAnalysis";

interface SourceCardProps {
  item: Evidence;
  index: number;
}

export default function SourceCard({ item, index }: SourceCardProps) {
  const stanceColor = {
    SUPPORTS: "bg-green-50 border-green-200",
    CONTRADICTS: "bg-red-50 border-red-200",
    NEUTRAL: "bg-gray-50 border-gray-200",
    UNKNOWN: "bg-gray-50 border-gray-200",
  }[item.stance];

  const stanceLabel = {
    SUPPORTS: "Supports Claim",
    CONTRADICTS: "Contradicts Claim",
    NEUTRAL: "Neutral",
    UNKNOWN: "Unknown",
  }[item.stance];

  const stanceBadgeColor = {
    SUPPORTS: "bg-green-100 text-green-700",
    CONTRADICTS: "bg-red-100 text-red-700",
    NEUTRAL: "bg-gray-100 text-gray-700",
    UNKNOWN: "bg-gray-100 text-gray-700",
  }[item.stance];

  return (
    <div className={`border ${stanceColor} rounded-lg p-6`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <a
            href={item.source_url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-lg font-semibold text-blue-600 hover:underline block mb-1"
          >
            Source {index}: {item.source_title || "Unnamed"}
          </a>
          <p className="text-sm text-gray-600">
            {new URL(item.source_url).hostname}
          </p>
        </div>
        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${stanceBadgeColor}`}>
          {stanceLabel}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        {item.source_date && (
          <div>
            <p className="text-gray-600">Published</p>
            <p className="font-medium text-gray-900">{item.source_date}</p>
          </div>
        )}
        {item.source_author && (
          <div>
            <p className="text-gray-600">Author</p>
            <p className="font-medium text-gray-900">{item.source_author}</p>
          </div>
        )}
      </div>

      <div className="mb-4">
        <p className="text-sm font-semibold text-gray-700 mb-2">Evidence Excerpt</p>
        <p className="text-sm text-gray-700 bg-white bg-opacity-50 rounded p-3 italic">
          "{item.excerpt}"
        </p>
      </div>

      <a
        href={item.source_url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 text-sm font-medium"
      >
        <span>View Full Source</span>
        <span>→</span>
      </a>
    </div>
  );
}
