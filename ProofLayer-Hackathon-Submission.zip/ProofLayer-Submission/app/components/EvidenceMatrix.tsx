"use client";

import { Evidence } from "@/lib/evidenceAnalysis";

interface EvidenceMatrixProps {
  evidence: Evidence[];
}

export default function EvidenceMatrix({ evidence }: EvidenceMatrixProps) {
  if (evidence.length === 0) {
    return (
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
        <p className="text-gray-600">No evidence available</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto border border-gray-200 rounded-lg">
      <table className="w-full">
        <thead>
          <tr className="bg-gray-50 border-b border-gray-200">
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 w-1/3">
              Source
            </th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900 w-20">
              Supports
            </th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900 w-24">
              Contradicts
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">
              Evidence
            </th>
          </tr>
        </thead>
        <tbody>
          {evidence.map((item, idx) => (
            <tr
              key={idx}
              className="border-b border-gray-200 hover:bg-gray-50 transition"
            >
              {/* Source */}
              <td className="px-4 py-3">
                <div className="text-sm">
                  <a
                    href={item.source_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline font-medium"
                  >
                    {item.source_title || "Unnamed Source"}
                  </a>
                  <p className="text-xs text-gray-500 mt-1">
                    {new URL(item.source_url).hostname}
                  </p>
                </div>
              </td>

              {/* Supports */}
              <td className="px-4 py-3 text-center">
                {item.stance === "SUPPORTS" && (
                  <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                    <span className="text-green-700 font-bold text-lg">✓</span>
                  </span>
                )}
              </td>

              {/* Contradicts */}
              <td className="px-4 py-3 text-center">
                {item.stance === "CONTRADICTS" && (
                  <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
                    <span className="text-red-700 font-bold text-lg">✕</span>
                  </span>
                )}
                {item.stance === "NEUTRAL" && (
                  <span className="text-gray-400 text-sm">—</span>
                )}
              </td>

              {/* Evidence Excerpt */}
              <td className="px-4 py-3">
                <p className="text-sm text-gray-700 line-clamp-2">
                  {item.excerpt}
                </p>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
