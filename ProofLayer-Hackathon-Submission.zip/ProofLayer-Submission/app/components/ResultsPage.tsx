"use client";

import { AnalysisResult, Verdict } from "@/lib/evidenceAnalysis";
import EvidenceMatrix from "./EvidenceMatrix";
import SourceCard from "./SourceCard";

interface ResultsPageProps {
  result: AnalysisResult;
  onReset: () => void;
}

const VERDICT_COLORS: Record<Verdict, { bg: string; text: string; border: string }> = {
  SUPPORTED: {
    bg: "bg-green-50",
    text: "text-green-900",
    border: "border-green-200",
  },
  CONTRADICTED: {
    bg: "bg-red-50",
    text: "text-red-900",
    border: "border-red-200",
  },
  MIXED: {
    bg: "bg-yellow-50",
    text: "text-yellow-900",
    border: "border-yellow-200",
  },
  INSUFFICIENT_EVIDENCE: {
    bg: "bg-gray-50",
    text: "text-gray-900",
    border: "border-gray-200",
  },
};

const VERDICT_LABELS: Record<Verdict, string> = {
  SUPPORTED: "Supported",
  CONTRADICTED: "Contradicted",
  MIXED: "Mixed Evidence",
  INSUFFICIENT_EVIDENCE: "Insufficient Evidence",
};

export default function ResultsPage({ result, onReset }: ResultsPageProps) {
  const colors = VERDICT_COLORS[result.verdict];

  return (
    <div className="min-h-screen bg-white py-12">
      <div className="w-full max-w-4xl mx-auto px-4">
        {/* Header */}
        <button
          onClick={onReset}
          className="text-blue-600 hover:text-blue-700 text-sm font-medium mb-8"
        >
          ← Back to Search
        </button>

        {/* Claim Display */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Claim Verification Result
          </h1>
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <p className="text-gray-800">
              <span className="font-semibold">Claim:</span> {result.claim}
            </p>
          </div>
        </div>

        {/* Verdict Card */}
        <div
          className={`${colors.bg} border ${colors.border} rounded-lg p-8 mb-8`}
        >
          <p className="text-sm font-semibold text-gray-600 mb-2">VERDICT</p>
          <h2 className={`text-4xl font-bold ${colors.text} mb-4`}>
            {VERDICT_LABELS[result.verdict]}
          </h2>
          <p className="text-lg text-gray-700 mb-6">{result.explanation}</p>

          <div className="flex items-center space-x-4">
            <div>
              <p className="text-sm text-gray-600 mb-1">Evidence Confidence</p>
              <p className="text-3xl font-bold text-gray-900">
                {result.confidence}%
              </p>
            </div>
            <div className="flex-1">
              <div className="bg-white bg-opacity-50 rounded-full h-3 overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full transition"
                  style={{ width: `${result.confidence}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Key Findings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {result.key_agreements.length > 0 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-green-900 mb-4">
                Supporting Evidence
              </h3>
              <ul className="space-y-2">
                {result.key_agreements.map((agreement, idx) => (
                  <li key={idx} className="flex items-start space-x-3">
                    <span className="text-green-600 font-bold mt-1">✓</span>
                    <span className="text-green-800 text-sm">{agreement}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {result.key_contradictions.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-red-900 mb-4">
                Contradicting Evidence
              </h3>
              <ul className="space-y-2">
                {result.key_contradictions.map((contradiction, idx) => (
                  <li key={idx} className="flex items-start space-x-3">
                    <span className="text-red-600 font-bold mt-1">✗</span>
                    <span className="text-red-800 text-sm">{contradiction}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Evidence Matrix */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Evidence Analysis
          </h2>
          <EvidenceMatrix evidence={result.evidence} />
        </div>

        {/* Individual Source Cards */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Sources Examined ({result.sources_analyzed})
          </h2>
          <div className="space-y-4">
            {result.evidence.map((item, idx) => (
              <SourceCard key={idx} item={item} index={idx + 1} />
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t pt-8 text-center text-gray-600">
          <p className="text-sm mb-4">
            ProofLayer analyzed {result.sources_analyzed} public web sources to
            generate this verdict.
          </p>
          <p className="text-xs text-gray-500 mb-6">
            Evidence transparency is at the core of ProofLayer. Every source is
            linked and every claim can be verified independently.
          </p>
          <button
            onClick={onReset}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded"
          >
            Verify Another Claim
          </button>
        </div>
      </div>
    </div>
  );
}
