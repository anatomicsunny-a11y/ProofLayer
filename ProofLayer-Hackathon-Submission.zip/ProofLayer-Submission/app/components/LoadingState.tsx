"use client";

import { useEffect, useState } from "react";

interface LoadingStateProps {
  claim: string;
}

const STAGES = [
  "Understanding claim",
  "Discovering sources",
  "Scraping web data",
  "Extracting evidence",
  "Analyzing sources",
  "Generating verdict",
];

export default function LoadingState({ claim }: LoadingStateProps) {
  const [currentStage, setCurrentStage] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStage((prev) => {
        if (prev < STAGES.length - 1) {
          return prev + 1;
        }
        return prev;
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white px-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Researching</h1>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-gray-800">
              <span className="font-semibold">Claim:</span> {claim}
            </p>
          </div>
        </div>

        {/* Progress Stages */}
        <div className="space-y-4 mb-12">
          {STAGES.map((stage, idx) => (
            <div key={idx} className="flex items-center space-x-4">
              <div className="relative">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition ${
                    idx < currentStage
                      ? "bg-green-500 text-white"
                      : idx === currentStage
                      ? "bg-blue-500 text-white"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {idx < currentStage ? "✓" : idx + 1}
                </div>
              </div>
              <div className="flex-1">
                <p
                  className={`font-medium ${
                    idx <= currentStage ? "text-gray-900" : "text-gray-400"
                  }`}
                >
                  {stage}
                </p>
                {idx === currentStage && (
                  <div className="flex space-x-1 mt-1">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }}></div>
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }}></div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Info */}
        <div className="text-center text-gray-600">
          <p className="text-sm">
            ProofLayer is collecting and analyzing evidence from public web sources...
          </p>
        </div>
      </div>
    </div>
  );
}
