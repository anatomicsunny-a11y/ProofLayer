import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ProofLayer - Turn Web Claims Into Evidence",
  description:
    "ProofLayer uses custom web scraping and AI analysis to verify claims against real public web evidence.",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#ffffff" />
      </head>
      <body className="antialiased bg-white text-gray-900">{children}</body>
    </html>
  );
}
