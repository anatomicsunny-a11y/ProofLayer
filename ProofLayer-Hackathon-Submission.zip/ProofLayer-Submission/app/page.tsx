"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import ClaimInput from "./components/ClaimInput";
import LoadingState from "./components/LoadingState";
import ResultsPage from "./components/ResultsPage";
import { AnalysisResult } from "@/lib/evidenceAnalysis";

type PageState = "input" | "loading" | "results" | "error";

interface ErrorState {
  message: string;
  details?: string;
}

export default function Home() {
  const [state, setState] = useState<PageState>("input");
  const [claim, setClaim] = useState<string>("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<ErrorState | null>(null);

  const handleSubmit = async (claimText: string) => {
    setClaim(claimText);
    setState("loading");
    setError(null);

    try {
      const response = await fetch("/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ claim: claimText }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.details || errorData.error || "Verification failed");
      }

      const analysisResult: AnalysisResult = await response.json();
      setResult(analysisResult);
      setState("results");
    } catch (err) {
      setError({
        message: err instanceof Error ? err.message : "Unknown error occurred",
      });
      setState("error");
    }
  };

  const handleReset = () => {
    setClaim("");
    setResult(null);
    setError(null);
    setState("input");
  };

  return (
    <div className="min-h-screen bg-white">
      {state === "input" && <ClaimInput onSubmit={handleSubmit} />}
      {state === "loading" && <LoadingState claim={claim} />}
      {state === "results" && result && (
        <ResultsPage result={result} onReset={handleReset} />
      )}
      {state === "error" && error && (
        <div className="min-h-screen flex items-center justify-center bg-red-50">
          <div className="w-full max-w-2xl px-6">
            <div className="bg-white border border-red-200 rounded-lg p-8">
              <h1 className="text-2xl font-bold text-red-900 mb-4">
                Verification Error
              </h1>
              <p className="text-red-700 mb-4">{error.message}</p>
              {error.details && (
                <pre className="bg-red-50 p-4 rounded text-sm overflow-auto mb-6">
                  {error.details}
                </pre>
              )}
              <button
                onClick={handleReset}
                className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-6 rounded"
              >
                Try Another Claim
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
