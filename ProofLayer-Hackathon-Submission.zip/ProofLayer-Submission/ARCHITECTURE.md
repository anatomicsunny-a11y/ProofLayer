# ProofLayer Architecture

## System Overview

ProofLayer is a full-stack Next.js application with a clear separation between frontend UI and backend evidence processing.

```
┌─────────────────────────────────────────────────────────────┐
│                      User Browser                           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              ProofLayer Frontend                    │   │
│  │  (React + TypeScript + Tailwind)                   │   │
│  │  ├── ClaimInput (user types claim)                 │   │
│  │  ├── LoadingState (shows progress)                │   │
│  │  ├── ResultsPage (displays verdict)               │   │
│  │  ├── EvidenceMatrix (visual table)                │   │
│  │  └── SourceCard (individual source details)       │   │
│  └─────────────────────────────────────────────────────┘   │
└──────────────────┬──────────────────────────────────────────┘
                   │ HTTP POST /api/verify
                   │ {"claim": "..."}
                   ▼
┌─────────────────────────────────────────────────────────────┐
│              ProofLayer Backend (Next.js)                  │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐  │
│  │     API Route: /api/verify                          │  │
│  │  ┌───────────────────────────────────────────────┐  │  │
│  │  │ 1. Parse claim                                 │  │  │
│  │  │ 2. Discover sources (Wikipedia URLs)           │  │  │
│  │  │ 3. Get scraper provider                        │  │  │
│  │  │ 4. Trigger scraper.scrape()                    │  │  │
│  │  │ 5. Pass to LLM analysis                        │  │  │
│  │  │ 6. Format and return verdict                   │  │  │
│  │  └───────────────────────────────────────────────┘  │  │
│  └─────────────────────────────────────────────────────┘  │
│                       │                                     │
│    ┌──────────────────┼──────────────────┐                │
│    ▼                  ▼                  ▼                │
│  ┌──────────┐    ┌──────────────┐   ┌──────────────┐     │
│  │Source    │    │Bright Data   │   │LLM Analysis  │     │
│  │Discovery │    │Integration   │   │Integration   │     │
│  └──────────┘    └──────────────┘   └──────────────┘     │
│    (lib/)        (lib/scraper/)      (lib/)               │
└─────────────────────────────────────────────────────────────┘
      │                 │                    │
      │                 │                    │
      └────────────┬────┴────────────┬───────┘
                   │                 │
                   ▼                 ▼
        ┌─────────────────┐   ┌──────────────────┐
        │  Wikipedia      │   │ OpenAI API       │
        │  (via Bright    │   │ (LLM Analysis)   │
        │   Data)         │   │                  │
        └─────────────────┘   └──────────────────┘
```

## Directory Structure

```
ProofLayer/
├── app/                          # Next.js App Router
│   ├── api/
│   │   └── verify/
│   │       └── route.ts          # Main verification endpoint
│   ├── components/
│   │   ├── ClaimInput.tsx        # User input component
│   │   ├── LoadingState.tsx      # Shows scraping + analysis progress
│   │   ├── ResultsPage.tsx       # Displays verdict and evidence
│   │   ├── EvidenceMatrix.tsx    # Visual table of sources vs claims
│   │   └── SourceCard.tsx        # Individual source display
│   ├── layout.tsx                # Root layout
│   ├── page.tsx                  # Home page
│   └── globals.css               # Global styles
│
├── lib/                          # Core business logic
│   ├── scraper/
│   │   ├── types.ts              # ScraperProvider interface
│   │   ├── brightDataProvider.ts # Bright Data API implementation
│   │   ├── developmentProvider.ts# Mock data for development
│   │   └── scraperManager.ts     # Selects correct provider
│   ├── brightData.ts             # Bright Data API utilities (legacy)
│   └── evidenceAnalysis.ts       # LLM integration for verdict generation
│
├── public/                       # Static assets (if any)
│
├── package.json                  # Dependencies
├── tsconfig.json                 # TypeScript configuration
├── next.config.js                # Next.js configuration
├── tailwind.config.ts            # Tailwind CSS configuration
├── postcss.config.js             # PostCSS configuration
│
├── README.md                     # Main project documentation
├── BRIGHT_DATA.md                # Bright Data integration details
├── ARCHITECTURE.md               # This file
├── AI_DISCLOSURE.md              # AI tools used
├── DEMO_SCRIPT.md                # How to demo the project
├── EXAMPLE_OUTPUT.json           # Example API response
└── .env.example                  # Environment variables template
```

## Data Flow

### 1. User Submits Claim

```typescript
// Frontend: User enters "Solar energy capacity increased..."
// POST /api/verify
{
  "claim": "Solar energy capacity increased significantly between 2023 and 2025."
}
```

### 2. Backend Processes Claim

**File:** `app/api/verify/route.ts`

```typescript
export async function POST(request: Request) {
  const { claim } = await request.json();
  
  // Step 1: Discover relevant sources
  const sources = discoverSources(claim);
  // Returns: ["https://en.wikipedia.org/wiki/Solar_energy", ...]
  
  // Step 2: Get appropriate scraper
  const scraper = getScraperProvider();
  // Returns: BrightDataProvider or DevelopmentProvider
  
  // Step 3: Scrape data
  const scrapedData = await scraper.scrape(sources);
  // Returns: [
  //   { url: "...", title: "...", content: "...", ... },
  //   { url: "...", title: "...", content: "...", ... }
  // ]
  
  // Step 4: Analyze with LLM
  const analysis = await analyzeEvidenceWithLLM(claim, scrapedData);
  // Returns: {
  //   verdict: "SUPPORTED",
  //   confidence: 82,
  //   explanation: "...",
  //   evidence: [...]
  // }
  
  // Step 5: Return result
  return Response.json(analysis);
}
```

### 3. Scraper Collects Data

**File:** `lib/scraper/brightDataProvider.ts`

#### Phase 1: Trigger

```typescript
POST https://api.brightdata.com/dca/trigger?collector=c_mt3xi0201l20zg4hoi&queue_next=1
Authorization: Bearer {BRIGHT_DATA_API_TOKEN}
Content-Type: application/json

[{}]  // Zero-input collector

Response:
{
  "collection_id": "j_abc123xyz789..."
}
```

#### Phase 2: Poll for Results

```typescript
GET https://api.brightdata.com/dca/dataset?id=j_abc123xyz789...
Authorization: Bearer {BRIGHT_DATA_API_TOKEN}

// Poll every 5 seconds until ready (max 120 attempts = 10 minutes)

// While building:
{ "status": "building" }

// When ready:
[
  {
    "url": "https://en.wikipedia.org/wiki/Solar_energy",
    "title": "Solar energy",
    "content": "Solar energy is radiant light and heat...",
    "domain": "wikipedia.org"
  },
  // ... more records
]
```

#### Phase 3: Normalize Data

```typescript
// Convert raw Bright Data response to internal format
private normalizeResults(data: unknown[]): ScrapedPage[] {
  return data.map((item: unknown) => {
    const obj = item as Record<string, unknown>;
    return {
      url: String(obj.url || ""),
      title: obj.title ? String(obj.title) : undefined,
      content: obj.content ? String(obj.content) : undefined,
      author: obj.author ? String(obj.author) : undefined,
      published_date: obj.published_date ? String(obj.published_date) : undefined,
      domain: obj.domain ? String(obj.domain) : undefined,
    };
  });
}
```

### 4. LLM Analyzes Evidence

**File:** `lib/evidenceAnalysis.ts`

```typescript
export async function analyzeEvidenceWithLLM(
  claim: string,
  sources: ScrapedPage[]
): Promise<AnalysisResult> {
  
  // Prepare prompt
  const prompt = `
    Claim: "${claim}"
    
    Sources:
    ${sources.map(s => `
      Source: ${s.title}
      URL: ${s.url}
      Content: ${s.content}
    `).join('\n---\n')}
    
    Based on the above sources, provide:
    1. Verdict (SUPPORTED, CONTRADICTED, MIXED, INSUFFICIENT_EVIDENCE)
    2. Confidence (0-100)
    3. Explanation
    4. Evidence assessment (which sources support/contradict)
    
    Respond in JSON format...
  `;
  
  // Call LLM
  const response = await fetch(LLM_API_ENDPOINT, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${LLM_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: LLM_MODEL,
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 2000
    })
  });
  
  // Parse response
  const data = await response.json();
  const analysis = JSON.parse(data.choices[0].message.content);
  
  // Return structured result
  return {
    claim,
    verdict: analysis.verdict,
    confidence: analysis.confidence,
    explanation: analysis.explanation,
    sources_analyzed: sources.length,
    evidence: analysis.evidence_assessment,
    key_agreements: analysis.supporting_evidence,
    key_contradictions: analysis.contradicting_evidence
  };
}
```

### 5. Frontend Displays Results

**File:** `app/page.tsx`

```typescript
// Results are displayed in phases:

// Phase 1: Loading
<LoadingState stage="Scraping 3 sources using Bright Data..." />

// Phase 2: Results
<ResultsPage result={{
  verdict: "SUPPORTED",
  confidence: 82,
  explanation: "Multiple sources...",
  evidence: [...]
}} />
```

## Component Architecture

### Frontend Components

#### ClaimInput.tsx
- User input field with character limit
- Real-time validation
- Submit button with loading state
- Passes claim to `/api/verify`

#### LoadingState.tsx
- Shows processing stages:
  - "Understanding claim..."
  - "Finding sources..."
  - "Scraping with Bright Data..."
  - "Analyzing evidence..."
  - "Generating verdict..."
- Animated spinner
- Estimated time remaining

#### ResultsPage.tsx
- Displays verdict (SUPPORTED/CONTRADICTED/MIXED/INSUFFICIENT_EVIDENCE)
- Shows confidence score (0-100)
- Explains reasoning
- Lists key findings
- Shows sources examined

#### EvidenceMatrix.tsx
- Visual table:
  - Rows: Sources
  - Columns: Supports / Contradicts / Evidence excerpt
- Clickable for details
- Color-coded for verdict type

#### SourceCard.tsx
- Individual source details
- Article title + URL
- Relevant excerpt
- Publication date
- Author information

## Backend Services

### ScraperProvider Interface

**File:** `lib/scraper/types.ts`

```typescript
interface ScraperProvider {
  scrape(urls: string[]): Promise<ScrapedPage[]>;
}

interface ScrapedPage {
  url: string;
  title?: string;
  content?: string;
  author?: string;
  published_date?: string;
  domain?: string;
}
```

### BrightDataProvider Implementation

**File:** `lib/scraper/brightDataProvider.ts`

- Implements `ScraperProvider` interface
- Handles all Bright Data API calls
- Implements polling with exponential backoff
- Comprehensive error handling
- Detailed logging for debugging

### ScraperManager

**File:** `lib/scraper/scraperManager.ts`

- Selects appropriate provider based on environment
- Production: Uses `BrightDataProvider` (requires BRIGHT_DATA_API_TOKEN)
- Development: Uses `DevelopmentProvider` (mock data)
- Throws error if production mode without credentials

### Evidence Analysis

**File:** `lib/evidenceAnalysis.ts`

- Sends scraped content + claim to LLM
- Parses LLM response
- Extracts verdict, confidence, explanation
- Identifies supporting vs. contradicting evidence
- Formats for UI display

## Error Handling

### Frontend

```typescript
// If API returns error
if (!response.ok) {
  showError("Failed to verify claim. Please try again.");
}
```

### Backend

```typescript
// Bright Data errors
if (response.status === 401) {
  throw new Error("Bright Data API token invalid");
}

// LLM errors
if (response.status === 429) {
  throw new Error("LLM API rate limit exceeded");
}

// Scraper timeout
if (pollingAttempts > MAX_POLLS) {
  throw new Error("Scraper did not complete within timeout");
}
```

## Environment Variables

Required for production:

```
BRIGHT_DATA_API_TOKEN=sk_...
BRIGHT_DATA_COLLECTOR_ID=c_mt3xi0201l20zg4hoi
LLM_API_KEY=sk-...
LLM_MODEL=gpt-4-turbo
LLM_API_ENDPOINT=https://api.openai.com/v1
```

Optional for development:

```
ENABLE_DEV_MODE=true  # Use mock data instead of Bright Data
```

## Deployment

### Vercel

1. Connect GitHub repository
2. Set environment variables in Vercel dashboard
3. Deploy (automatic on push to main)

### Local Development

```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Performance Considerations

### Frontend
- React components memoized to prevent re-renders
- Lazy loading for heavy components
- CSS-in-JS minimal (using Tailwind)

### Backend
- Parallel LLM requests if multiple claims
- Caching of source discovery results
- Polling optimization (exponential backoff)

### External APIs
- Bright Data: 10-30s (network + scraping)
- LLM: 5-10s (inference)
- **Total: 20-50s** end-to-end

## Scalability

Current limitations:
- Single Bright Data collector (Wikipedia only)
- No database (stateless)
- No caching layer

To scale:
1. Add multiple collectors for different sources
2. Cache source discovery results
3. Add database for claim + result history
4. Implement rate limiting
5. Add batch processing for multiple claims

## Security

### API Keys
- Stored in environment variables only
- Never logged
- Never exposed in responses
- Rotated regularly

### User Input
- Claims sanitized before LLM
- HTML entities escaped in responses
- No SQL injection (no database)

### Third-party Services
- Only public APIs used (Bright Data, OpenAI)
- HTTPS for all requests
- Token-based authentication

## Testing Strategy

### Unit Tests
- Source discovery logic
- Data normalization
- Error handling

### Integration Tests
- Full /api/verify flow
- Bright Data integration
- LLM integration

### E2E Tests
- User submits claim
- Sees loading states
- Receives verdict
- Can click sources

---

See `README.md` for more details about features and usage.
