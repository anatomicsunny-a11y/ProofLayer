# ProofLayer Demo Examples

This document contains example claims that can be used to demonstrate and test ProofLayer.

## Quick Demo Claims

Copy any of these claims and paste them into ProofLayer to see it in action.

### Example 1: Renewable Energy (SUPPORTED)

**Claim:**
```
Solar energy capacity increased significantly between 2023 and 2025.
```

**Expected Result:**
- **Verdict:** SUPPORTED
- **Confidence:** 75-90%
- **Key Finding:** Multiple sources confirm solar capacity grew from ~1.0 TW to 1.5 TW
- **Sources:** 3 Wikipedia articles on renewable energy
- **Evidence:** Specific capacity numbers, growth rates, fastest-growing technology designation

---

### Example 2: Artificial Intelligence (SUPPORTED)

**Claim:**
```
Artificial intelligence language models have improved reasoning capabilities in recent years.
```

**Expected Result:**
- **Verdict:** SUPPORTED
- **Confidence:** 80-95%
- **Key Finding:** Sources confirm emergent reasoning abilities in modern LLMs
- **Sources:** AI and Machine Learning Wikipedia articles
- **Evidence:** Mentions of improved problem-solving, mathematical abilities, reasoning advances

---

### Example 3: Climate Change (SUPPORTED)

**Claim:**
```
Global temperatures have increased over the past century.
```

**Expected Result:**
- **Verdict:** SUPPORTED
- **Confidence:** 85-95%
- **Key Finding:** Multiple independent sources confirm warming trend
- **Sources:** Climate Change, Global Warming Wikipedia articles
- **Evidence:** 1.1°C increase since pre-industrial times, unprecedented warming

---

## Testing Different Verdict Outcomes

### SUPPORTED Verdict

The claim has strong evidence supporting it.

```
Test: "Renewable energy is growing globally."
Expected: SUPPORTED (multiple sources mention growth, adoption, capacity increases)
```

### CONTRADICTED Verdict

The claim is contradicted by evidence.

```
Test: "Solar energy is the largest energy source globally."
Expected: CONTRADICTED (sources indicate it's rapidly growing but not yet largest)
```

### MIXED Verdict

Evidence both supports and contradicts the claim.

```
Test: "AI is universally beneficial with no significant risks."
Expected: MIXED (some sources praise benefits, others mention limitations/risks)
```

### INSUFFICIENT_EVIDENCE Verdict

Not enough evidence to determine verdict.

```
Test: "Specific renewable energy policy from [obscure country] in 2025."
Expected: INSUFFICIENT_EVIDENCE (too specific, no available public data)
```

---

## Test Scenarios

### Test 1: Basic Claim

**Claim:** Solar energy capacity increased significantly between 2023 and 2025.

**Test Steps:**
1. Open ProofLayer
2. Paste the claim
3. Click "Verify Claim"
4. Observe loading states (5-10 seconds)
5. Review verdict and sources
6. Click on a source link to verify
7. Check evidence matrix

**Expected UX:**
- ✓ Loading states show progress
- ✓ Results appear after scraping and LLM analysis
- ✓ Evidence matrix displays correctly
- ✓ Source links are clickable and accurate

---

### Test 2: Empty Claim

**Test Steps:**
1. Leave the claim field empty
2. Click "Verify Claim"

**Expected Behavior:**
- ✓ Button should be disabled (grayed out)
- ✓ Or error message appears if clicked anyway

---

### Test 3: Very Long Claim

**Claim:** [Paste a 600+ character claim]

**Expected Behavior:**
- ✓ Character counter shows "600+/500"
- ✓ Submit button disabled
- ✓ Error message if limit exceeded

---

### Test 4: Scraper Failure (for testing error handling)

**Test Steps:**
1. Disconnect from internet OR
2. Remove BRIGHT_DATA_API_TOKEN from .env

**Expected Behavior:**
- ✓ Application falls back to development mode OR
- ✓ Error message clearly states scraper failed
- ✓ Error does not crash the app
- ✓ User can try again

---

### Test 5: Responsive Design

**Test Steps:**
1. Open ProofLayer on desktop browser
2. Verify layout looks good
3. Resize to tablet size (768px)
4. Verify responsiveness
5. Resize to mobile size (375px)
6. Verify mobile layout

**Expected Behavior:**
- ✓ Content readable at all sizes
- ✓ Evidence matrix scrolls horizontally on mobile
- ✓ Buttons have good touch targets
- ✓ Text is not cramped

---

## Development Mode Testing

When Bright Data credentials are not configured, ProofLayer automatically uses **Development Mode**.

### How to Test Development Mode

1. Ensure `.env.local` does NOT have BRIGHT_DATA_API_TOKEN or BRIGHT_DATA_COLLECTOR_ID set
2. Start the dev server: `npm run dev`
3. Open http://localhost:3000
4. Enter any claim
5. Click "Verify Claim"

**Expected Behavior:**
- ✓ Claims about renewable energy, AI, or climate return mock data
- ✓ Results are realistic but clearly marked as development data
- ✓ All UI components work correctly
- ✓ Evidence analysis and verdict generation work

### Mock Data Topics

Development mode has mock data for:

- **Renewable Energy** - Keywords: renewable, solar, wind, energy
- **Artificial Intelligence** - Keywords: AI, artificial, machine, learning
- **Climate Change** - Keywords: climate, temperature, warming, greenhouse

Try these claims to get development data:

- "Renewable energy is growing."
- "AI has improved."
- "Climate is changing."

---

## Transitioning to Real Bright Data

Once you have Bright Data credentials configured:

1. Set `BRIGHT_DATA_API_TOKEN` in `.env.local`
2. Set `BRIGHT_DATA_COLLECTOR_ID` in `.env.local`
3. Restart dev server
4. ProofLayer will automatically use real Bright Data instead of development mode
5. Verify that real scraper is working by checking server logs

---

## Monitoring and Debugging

### Server Logs

When running `npm run dev`, the server logs show:

```
Using Bright Data Scraper Studio
Scraping 3 sources using Bright Data Scraper Studio
Bright Data polling (1/60): processing...
Bright Data polling (2/60): processing...
...
Analyzing 3 evidence sources...
```

Or, if in development mode:

```
⚠️ Bright Data not configured. Using Development Mode with mock data.
Set BRIGHT_DATA_API_TOKEN and BRIGHT_DATA_COLLECTOR_ID to use real scraping.
Scraping 3 sources using Development Mode (Mock Data)
Analyzing 3 evidence sources...
```

### API Response Inspection

In browser DevTools (Network tab), you can inspect:

1. Request to `/api/verify`
2. Response structure includes:
   - `claim`
   - `verdict`
   - `confidence`
   - `explanation`
   - `evidence` (array of sources)
   - `key_agreements`
   - `key_contradictions`

---

## Performance Benchmarks

Target performance for ProofLayer:

| Operation | Target | Notes |
|-----------|--------|-------|
| Claim input to submission | <1s | Instant UI response |
| Bright Data scraping | 10-30s | Depends on number of sources and Bright Data latency |
| LLM analysis | 5-10s | OpenAI API latency |
| Total end-to-end | 20-50s | Scraping + LLM analysis |
| Development mode | 2-3s | No actual scraping, mock data only |

---

## Example API Calls

### Using cURL

```bash
# Test ProofLayer /api/verify endpoint
curl -X POST http://localhost:3000/api/verify \
  -H "Content-Type: application/json" \
  -d '{
    "claim": "Solar energy capacity increased between 2023 and 2025."
  }'
```

### Using fetch (JavaScript)

```javascript
const response = await fetch("/api/verify", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    claim: "Solar energy capacity increased between 2023 and 2025.",
  }),
});

const result = await response.json();
console.log("Verdict:", result.verdict);
console.log("Confidence:", result.confidence);
console.log("Sources analyzed:", result.sources_analyzed);
```

### Using Python

```python
import requests
import json

url = "http://localhost:3000/api/verify"
payload = {
    "claim": "Solar energy capacity increased between 2023 and 2025."
}

response = requests.post(url, json=payload)
result = response.json()

print(f"Verdict: {result['verdict']}")
print(f"Confidence: {result['confidence']}")
print(f"Explanation: {result['explanation']}")
```

---

## Troubleshooting

### Issue: "Bright Data is not configured"

**Solution:**
- Ensure `.env.local` has BRIGHT_DATA_API_TOKEN and BRIGHT_DATA_COLLECTOR_ID
- Restart dev server after setting environment variables
- Check that environment variables are correctly loaded: `console.log(process.env.BRIGHT_DATA_API_TOKEN)`

### Issue: Scraping taking too long

**Solution:**
- Bright Data API may be under load
- Check network tab in DevTools to see latency
- Retry after a few moments
- For development, use mock data mode (don't set Bright Data env vars)

### Issue: LLM API errors

**Solution:**
- Verify LLM_API_KEY is set correctly
- Check API key is not expired
- Verify LLM_MODEL is correct (e.g., "gpt-4-turbo")
- Check API rate limits have not been exceeded

### Issue: Evidence matrix not showing

**Solution:**
- Ensure scraped data has expected fields (url, title, content)
- Check browser console for JavaScript errors
- Verify LLM response includes "evidence_assessment" array

---

## Feedback

If testing uncovers issues:

1. Check server logs for errors
2. Check browser DevTools for client-side errors
3. Verify environment variables are set
4. Try with development mock data first
5. Report the error with reproduction steps

Good luck demoing ProofLayer! 🚀
