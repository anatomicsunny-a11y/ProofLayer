/**
 * Bright Data Scraper Studio Integration
 * 
 * This module handles communication with Bright Data's Scraper Studio API.
 * It triggers custom scrapers and retrieves structured web data.
 */

const BRIGHT_DATA_API_BASE = "https://api.brightdata.com/datasets/v3/pull";
const MAX_POLL_ATTEMPTS = 60;
const POLL_INTERVAL_MS = 2000;

interface BrightDataInput {
  url: string;
}

interface BrightDataResult {
  url: string;
  title?: string;
  content?: string;
  date?: string;
  author?: string;
  [key: string]: unknown;
}

interface BrightDataTriggerResponse {
  snapshot_id: string;
}

/**
 * Trigger a Bright Data Scraper Studio collector with given inputs
 */
export async function triggerScraper(
  inputs: BrightDataInput[]
): Promise<string> {
  const apiToken = process.env.BRIGHT_DATA_API_TOKEN;
  const collectorId = process.env.BRIGHT_DATA_COLLECTOR_ID;

  if (!apiToken || !collectorId) {
    throw new Error(
      "Missing Bright Data configuration. Ensure BRIGHT_DATA_API_TOKEN and BRIGHT_DATA_COLLECTOR_ID are set."
    );
  }

  const url = `${BRIGHT_DATA_API_BASE}/${collectorId}`;

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(inputs),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Bright Data API error: ${response.status} - ${errorText}`);
    }

    const data: BrightDataTriggerResponse = await response.json();
    return data.snapshot_id;
  } catch (error) {
    throw new Error(
      `Failed to trigger Bright Data scraper: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}

/**
 * Poll Bright Data API for scraper results
 */
export async function pollResults(
  snapshotId: string
): Promise<BrightDataResult[]> {
  const apiToken = process.env.BRIGHT_DATA_API_TOKEN;
  const collectorId = process.env.BRIGHT_DATA_COLLECTOR_ID;

  if (!apiToken || !collectorId) {
    throw new Error("Missing Bright Data configuration.");
  }

  for (let attempt = 1; attempt <= MAX_POLL_ATTEMPTS; attempt++) {
    try {
      const url = `${BRIGHT_DATA_API_BASE}/${collectorId}/snapshot/${snapshotId}`;
      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${apiToken}`,
        },
      });

      if (response.status === 202) {
        // Still processing
        console.log(
          `Polling Bright Data (attempt ${attempt}/${MAX_POLL_ATTEMPTS})...`
        );
        await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
        continue;
      }

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(
          `Bright Data API error: ${response.status} - ${errorText}`
        );
      }

      const data: BrightDataResult[] = await response.json();
      return data;
    } catch (error) {
      if (attempt === MAX_POLL_ATTEMPTS) {
        throw new Error(
          `Failed to retrieve Bright Data results after ${MAX_POLL_ATTEMPTS} attempts: ${
            error instanceof Error ? error.message : String(error)
          }`
        );
      }
      await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
    }
  }

  throw new Error("Bright Data scraper polling timeout");
}

/**
 * Run the complete scraper workflow: trigger → poll → return results
 */
export async function runScraper(urls: string[]): Promise<BrightDataResult[]> {
  const inputs: BrightDataInput[] = urls.map((url) => ({ url }));
  const snapshotId = await triggerScraper(inputs);
  const results = await pollResults(snapshotId);
  return results;
}
