/**
 * Development Scraper Provider
 * 
 * ⚠️ DEVELOPMENT ONLY - For local testing without Bright Data credentials
 * 
 * This provider returns realistic mock data for UI development and testing.
 * It is NOT used in production and is clearly labeled as development mode.
 * 
 * The final demo MUST use the real Bright Data provider.
 */

import { ScraperProvider, ScraperInput, ScraperResult, ScrapedPage } from "./types";

// Mock data repository organized by topic
const MOCK_DATA_REPOSITORY: {
  [key: string]: ScrapedPage[];
} = {
  renewable_energy: [
    {
      url: "https://en.wikipedia.org/wiki/Renewable_energy",
      title: "Renewable Energy - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-06-15",
      content:
        "Renewable energy is energy derived from natural sources that are continuously replenished. By 2024, renewables accounted for approximately 30% of global electricity generation, with solar and wind being the fastest-growing sources. Global renewable capacity increased by 50% between 2020 and 2025, driven by policy support and declining costs.",
    },
    {
      url: "https://en.wikipedia.org/wiki/Solar_energy",
      title: "Solar Energy - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-05-20",
      content:
        "Solar energy is radiant energy from the sun. Global solar capacity reached 1.5 TW in 2025, representing a 15x increase since 2015. Solar photovoltaics is now the fastest-growing energy technology, with annual installations increasing by 20-25% year over year.",
    },
    {
      url: "https://en.wikipedia.org/wiki/Wind_power",
      title: "Wind Power - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-04-10",
      content:
        "Wind power is the harnessing of wind energy to produce electricity. Global installed wind capacity exceeded 1.3 TW by 2025. Wind energy generation is a significant and growing part of global electricity supply, particularly in Europe, China, and the United States.",
    },
  ],
  artificial_intelligence: [
    {
      url: "https://en.wikipedia.org/wiki/Artificial_intelligence",
      title: "Artificial Intelligence - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-08-01",
      content:
        "Artificial intelligence (AI) encompasses machine learning, deep learning, and various computational approaches to simulate human-like intelligence. Since 2020, there have been significant improvements in natural language processing, computer vision, and reasoning capabilities. Modern language models have demonstrated improved understanding of complex tasks and improved reasoning.",
    },
    {
      url: "https://en.wikipedia.org/wiki/Large_language_model",
      title: "Large Language Model - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-07-15",
      content:
        "Large language models (LLMs) are neural networks trained on large corpora of text data. Recent advances in LLM capabilities (2023-2025) have shown improved reasoning, mathematical problem-solving, and coding abilities. LLMs now exhibit emergent capabilities not explicitly trained for.",
    },
    {
      url: "https://en.wikipedia.org/wiki/Machine_learning",
      title: "Machine Learning - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-06-30",
      content:
        "Machine learning is a subset of artificial intelligence that focuses on the development of algorithms and statistical models. The field has experienced explosive growth, with applications spanning from computer vision to natural language processing.",
    },
  ],
  climate_change: [
    {
      url: "https://en.wikipedia.org/wiki/Climate_change",
      title: "Climate Change - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-08-05",
      content:
        "Climate change refers to long-term shifts in global temperatures and climate patterns. Global average temperatures have increased by approximately 1.1°C since pre-industrial times (by 2025). The warming is primarily driven by human activities, particularly the emission of greenhouse gases.",
    },
    {
      url: "https://en.wikipedia.org/wiki/Global_warming",
      title: "Global Warming - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-07-20",
      content:
        "Global warming is the observed century-scale rise in the mean temperature of Earth's climate system. Multiple lines of evidence confirm that the current warming trend is unprecedented over the past 2000 years and is primarily caused by human influence.",
    },
    {
      url: "https://en.wikipedia.org/wiki/Greenhouse_gas",
      title: "Greenhouse Gas - Wikipedia",
      domain: "wikipedia.org",
      author: "Wikipedia Contributors",
      published_date: "2025-06-25",
      content:
        "Greenhouse gases trap heat in the atmosphere, warming the planet. Carbon dioxide, methane, and nitrous oxide are the primary anthropogenic greenhouse gases. Concentrations have increased significantly since the Industrial Revolution, driving observable climate change.",
    },
  ],
};

export class DevelopmentProvider implements ScraperProvider {
  getName(): string {
    return "Development Mode (Mock Data)";
  }

  isConfigured(): boolean {
    return true; // Always available for testing
  }

  async scrape(input: ScraperInput): Promise<ScraperResult> {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 800));

    try {
      // Determine topic from URLs
      const topic = this.detectTopic(input.urls);
      let mockPages = MOCK_DATA_REPOSITORY[topic] || [];

      // Limit to reasonable number
      mockPages = mockPages.slice(0, Math.min(input.urls.length, 3));

      // If no mock data found, return empty
      if (mockPages.length === 0) {
        return {
          pages: [],
          status: "partial",
          error: `No development mock data for topic. Using generic development data.`,
          timestamp: new Date().toISOString(),
          provider: "development",
        };
      }

      return {
        pages: mockPages,
        status: "success",
        timestamp: new Date().toISOString(),
        provider: "development",
      };
    } catch (error) {
      return {
        pages: [],
        status: "error",
        error: `Development provider error: ${
          error instanceof Error ? error.message : String(error)
        }`,
        timestamp: new Date().toISOString(),
        provider: "development",
      };
    }
  }

  private detectTopic(urls: string[]): string {
    const urlText = urls.join(" ").toLowerCase();

    if (
      urlText.includes("renewable") ||
      urlText.includes("solar") ||
      urlText.includes("wind") ||
      urlText.includes("energy")
    ) {
      return "renewable_energy";
    }

    if (
      urlText.includes("ai") ||
      urlText.includes("artificial") ||
      urlText.includes("machine") ||
      urlText.includes("learning") ||
      urlText.includes("language")
    ) {
      return "artificial_intelligence";
    }

    if (
      urlText.includes("climate") ||
      urlText.includes("temperature") ||
      urlText.includes("warming") ||
      urlText.includes("greenhouse")
    ) {
      return "climate_change";
    }

    return "renewable_energy"; // Default topic
  }
}
