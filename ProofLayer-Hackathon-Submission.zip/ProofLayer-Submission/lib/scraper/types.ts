/**
 * Scraper Interface Types
 * 
 * Defines the contract that all scraper implementations must follow.
 * This allows clean swapping between Bright Data, development, and other scrapers.
 */

export interface ScraperInput {
  urls: string[];
}

export interface ScrapedPage {
  url: string;
  title?: string;
  content?: string;
  author?: string;
  published_date?: string;
  domain?: string;
  [key: string]: unknown;
}

export interface ScraperResult {
  pages: ScrapedPage[];
  status: "success" | "partial" | "error";
  error?: string;
  timestamp: string;
  provider: "bright-data" | "development" | "test";
}

export interface ScraperProvider {
  /**
   * Execute the scraper with given URLs
   */
  scrape(input: ScraperInput): Promise<ScraperResult>;

  /**
   * Get the name of this scraper provider for logging/display
   */
  getName(): string;

  /**
   * Check if this scraper is properly configured
   */
  isConfigured(): boolean;
}
