/**
 * Evidence Analysis Engine
 * 
 * Takes structured web data from Bright Data and uses an LLM
 * to analyze evidence for a given claim.
 */

export type Verdict = "SUPPORTED" | "CONTRADICTED" | "MIXED" | "INSUFFICIENT_EVIDENCE";

export interface Evidence {
  source_url: string;
  source_title?: string;
  source_date?: string;
  source_author?: string;
  excerpt: string;
  stance: "SUPPORTS" | "CONTRADICTS" | "NEUTRAL" | "UNKNOWN";
}

export interface AnalysisResult {
  claim: string;
  verdict: Verdict;
  confidence: number; // 0-100
  explanation: string;
  evidence: Evidence[];
  sources_analyzed: number;
  key_agreements: string[];
  key_contradictions: string[];
}

/**
 * Call an LLM API to analyze evidence
 * Supports OpenAI-compatible APIs
 */
export async function analyzeEvidenceWithLLM(
  claim: string,
  scrapedData: Array<{
    url: string;
    title?: string;
    content?: string;
    date?: string;
    author?: string;
  }>
): Promise<AnalysisResult> {
  const llmApiKey = process.env.LLM_API_KEY;
  const llmModel = process.env.LLM_MODEL || "gpt-4-turbo";
  const llmEndpoint = process.env.LLM_API_ENDPOINT || "https://api.openai.com/v1";

  if (!llmApiKey) {
    throw new Error("Missing LLM_API_KEY environment variable");
  }

  // Prepare the evidence for the LLM
  const evidenceSummary = scrapedData
    .map(
      (item, idx) =>
        `[Source ${idx + 1}]
Title: ${item.title || "Unknown"}
URL: ${item.url}
Date: ${item.date || "Unknown"}
Author: ${item.author || "Unknown"}
Content (excerpt):
${item.content ? item.content.substring(0, 500) : "No content available"}
---`
    )
    .join("\n\n");

  const systemPrompt = `You are a fact-checking and evidence analysis expert. Your role is to:

1. Analyze a user's claim
2. Review provided evidence from web sources
3. Determine if the evidence SUPPORTS, CONTRADICTS, or is NEUTRAL/INSUFFICIENT for the claim
4. Provide a clear verdict and confidence level
5. Explain your reasoning transparently

IMPORTANT RULES:
- Only reason from the PROVIDED evidence. Do not use your training data as evidence.
- Do not fabricate sources, quotes, or statistics.
- If evidence is missing or insufficient, clearly state that.
- When sources conflict, acknowledge both perspectives.
- Confidence is your assessment based on evidence quality and quantity (0-100), not a probability.

Respond in valid JSON format with this structure:
{
  "verdict": "SUPPORTED|CONTRADICTED|MIXED|INSUFFICIENT_EVIDENCE",
  "confidence": <0-100>,
  "explanation": "<clear explanation of reasoning>",
  "key_agreements": ["<point 1>", "<point 2>"],
  "key_contradictions": ["<point 1>", "<point 2>"],
  "evidence_assessment": [
    {
      "source_index": 0,
      "url": "url",
      "stance": "SUPPORTS|CONTRADICTS|NEUTRAL|UNKNOWN",
      "reasoning": "<brief explanation>"
    }
  ]
}`;

  const userPrompt = `Analyze this claim: "${claim}"

Here is the evidence collected from public web sources:

${evidenceSummary}

Based ONLY on this evidence, what is your assessment of the claim?`;

  try {
    const response = await fetch(`${llmEndpoint}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${llmApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: llmModel,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.2,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`LLM API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    const contentStr = data.choices?.[0]?.message?.content;

    if (!contentStr) {
      throw new Error("Invalid LLM response format");
    }

    // Parse the JSON response
    let llmAnalysis;
    try {
      // Extract JSON from the response (in case there's surrounding text)
      const jsonMatch = contentStr.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error("No JSON found in LLM response");
      }
      llmAnalysis = JSON.parse(jsonMatch[0]);
    } catch (parseError) {
      throw new Error(`Failed to parse LLM response as JSON: ${contentStr}`);
    }

    // Build the evidence array with LLM assessment
    const evidenceArray: Evidence[] = scrapedData.map((item, idx) => {
      const assessment =
        llmAnalysis.evidence_assessment?.find(
          (e: { source_index: number }) => e.source_index === idx
        ) || { stance: "UNKNOWN", reasoning: "" };

      return {
        source_url: item.url,
        source_title: item.title,
        source_date: item.date,
        source_author: item.author,
        excerpt: item.content ? item.content.substring(0, 300) : "No excerpt",
        stance: assessment.stance,
      };
    });

    return {
      claim,
      verdict: llmAnalysis.verdict || "INSUFFICIENT_EVIDENCE",
      confidence: llmAnalysis.confidence || 0,
      explanation: llmAnalysis.explanation || "Unable to analyze evidence",
      evidence: evidenceArray,
      sources_analyzed: scrapedData.length,
      key_agreements: llmAnalysis.key_agreements || [],
      key_contradictions: llmAnalysis.key_contradictions || [],
    };
  } catch (error) {
    throw new Error(
      `LLM analysis failed: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}
