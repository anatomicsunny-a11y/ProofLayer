# ProofLayer

**Turn web claims into evidence.**

ProofLayer is a web evidence engine that verifies factual claims by collecting public web data, analyzing evidence, and producing transparent verdicts backed by real sources.

---

## Problem

The internet contains millions of answers, but finding trustworthy evidence is difficult. Users often rely on search engines or LLMs, but:

- Search engines return links without context or evaluation
- LLMs can hallucinate, confabulate citations, or rely on outdated training data
- It's hard to know which sources are reliable or how to weigh conflicting claims
- The reasoning behind conclusions is often opaque

ProofLayer solves this by collecting real public web evidence and reasoning transparently over it.

---

## Solution

ProofLayer uses:

1. **Custom Bright Data Scraper** - Collects structured data from public websites
2. **Evidence Extraction** - Identifies relevant claims and evidence from collected pages
3. **AI Analysis** - Uses an LLM to analyze evidence objectively
4. **Transparent Verdict** - Produces a verdict with confidence level, backed by specific sources

**The key principle:** Instead of asking an LLM "Is this true?", ProofLayer asks it "Here is evidence collected from public webpages—analyze this evidence and explain whether it supports or contradicts the claim."

---

## How It Works

### User Flow

1. User enters a claim
2. ProofLayer discovers relevant public sources
3. ProofLayer's custom Bright Data scraper collects structured data from those sources
4. ProofLayer extracts relevant evidence from the collected data
5. An LLM analyzes the evidence against the claim
6. A transparent verdict is produced with:
   - Verdict (SUPPORTED / CONTRADICTED / MIXED / INSUFFICIENT_EVIDENCE)
   - Confidence score (0-100)
   - Explanation of reasoning
   - Evidence matrix showing agreement/contradiction
   - Source URLs and excerpts

### Architecture

```
USER
  ↓
CLAIM INPUT
  ↓
SOURCE DISCOVERY
  ↓
BRIGHT DATA CUSTOM SCRAPER
  ↓
STRUCTURED WEB DATA
  ↓
EVIDENCE EXTRACTION
  ↓
EVIDENCE ANALYSIS (LLM)
  ↓
VERDICT + CONFIDENCE + EVIDENCE TRAIL
  ↓
RESULTS PAGE
```

---

## Features

### Core Features

- **Claim Input** - Simple, clean interface for entering claims to verify
- **Evidence Collection** - Custom Bright Data scraper for reliable web data
- **Evidence Matrix** - Visual comparison of sources and their stance on the claim
- **Source Cards** - Detailed information on each source with excerpts and URLs
- **Confidence Scoring** - Evidence-based confidence level (not a false probability)
- **Transparent Reasoning** - See exactly which sources support/contradict the claim

### Research States

ProofLayer shows researchers its thought process:

- Understanding claim
- Discovering sources
- Scraping web data
- Extracting evidence
- Analyzing sources
- Generating verdict

### Error Handling

Gracefully handles:

- Empty claims
- Invalid URLs
- Scraper failures
- Missing metadata
- Insufficient evidence
- LLM API errors

ProofLayer never converts errors into fake successful results.

---

## Technology Stack

### Frontend

- **Next.js 14** - React framework with API routes
- **React 18** - UI components
- **Tailwind CSS** - Styling
- **TypeScript** - Type safety

### Backend

- **Next.js API Routes** - Serverless backend
- **Bright Data Scraper Studio** - Web scraping
- **OpenAI API** (or compatible) - Evidence analysis

### Infrastructure

- **Vercel** (recommended) - Deployment
- **GitHub** - Source control

---

## Bright Data Scraper Studio Integration

### Why Bright Data?

ProofLayer's core value proposition is evidence collection and analysis. Bright Data Scraper Studio is used because:

1. **Reliability** - Handles JavaScript rendering, proxy rotation, anti-bot detection
2. **Structured Data** - Returns clean JSON that we can process programmatically
3. **Customization** - AI-powered scraper builder allows targeting specific data
4. **Transparency** - We control exactly what data is collected and how

### Custom Scraper

Instead of using pre-built scrapers from Bright Data's library, ProofLayer uses a **custom scraper** that:

- Targets public, non-restricted information
- Extracts relevant fields: title, URL, content, publication date, author
- Respects robots.txt and rate limits
- Preserves source URLs and metadata

### How It's Integrated

1. **Configuration** - Environment variables specify the collector ID and API token
2. **Trigger** - Application POSTs URLs to Bright Data's `/dca/trigger` endpoint
3. **Polling** - Application polls `/dca/trigger/{id}/snapshot/{snapshot_id}` for results
4. **Parsing** - Structured JSON results are normalized and passed to evidence engine
5. **Fallback** - If Bright Data is not configured, development mode uses realistic mock data

### Example Request

```bash
curl -X POST "https://api.brightdata.com/datasets/v3/pull/c_abc123" \
  -H "Authorization: Bearer your_api_token" \
  -H "Content-Type: application/json" \
  -d '[{"url": "https://en.wikipedia.org/wiki/Solar_energy"}]'
```

### Example Response

```json
{
  "snapshot_id": "j_xyz789"
}
```

Polling that snapshot returns:

```json
[
  {
    "url": "https://en.wikipedia.org/wiki/Solar_energy",
    "title": "Solar Energy - Wikipedia",
    "content": "Solar energy is radiant energy...",
    "author": "Wikipedia Contributors",
    "published_date": "2025-06-15",
    "domain": "wikipedia.org"
  }
]
```

---

## AI Evidence Pipeline

### Evidence Analysis

The LLM receives:

- The user's claim
- Structured evidence from the Bright Data scraper
- Instructions to reason ONLY from supplied evidence

### LLM Responsibilities

1. **Summarize** relevant evidence
2. **Classify** each source: SUPPORTS, CONTRADICTS, NEUTRAL, UNKNOWN
3. **Identify** key agreements and contradictions
4. **Produce** a verdict: SUPPORTED | CONTRADICTED | MIXED | INSUFFICIENT_EVIDENCE
5. **Explain** reasoning transparently
6. **Acknowledge** limitations

### What the LLM Must NOT Do

- Invent sources or citations
- Invent quotations or statistics
- Claim it accessed information it didn't receive
- Hide contradictory evidence
- Treat its training data as evidence

The LLM's only input is the evidence collected by ProofLayer. It has no access to the internet.

---

## Example Structured Output

### Input

```json
{
  "claim": "Solar energy capacity increased significantly between 2023 and 2025."
}
```

### Output

```json
{
  "claim": "Solar energy capacity increased significantly between 2023 and 2025.",
  "verdict": "SUPPORTED",
  "confidence": 87,
  "explanation": "Multiple sources confirm that global solar capacity grew substantially in this period. Wikipedia reports solar photovoltaics as the fastest-growing energy technology with annual installations increasing 20-25% year over year. Aggregate capacity increased from approximately 1.0 TW in 2023 to 1.5 TW by 2025.",
  "sources_analyzed": 3,
  "key_agreements": [
    "Solar is fastest-growing energy source",
    "Capacity more than doubled 2015-2025",
    "Annual installations growing 20-25% YoY"
  ],
  "key_contradictions": [],
  "evidence": [
    {
      "source_url": "https://en.wikipedia.org/wiki/Solar_energy",
      "source_title": "Solar Energy - Wikipedia",
      "source_date": "2025-06-15",
      "source_author": "Wikipedia Contributors",
      "excerpt": "Global solar capacity reached 1.5 TW in 2025, representing a 15x increase since 2015.",
      "stance": "SUPPORTS"
    }
  ]
}
```

---

## Installation

### Prerequisites

- Node.js 18+
- npm or yarn
- Bright Data account with Scraper Studio access (optional, for production)

### Setup

1. **Clone the repository**

   ```bash
   git clone https://github.com/yourusername/prooflayer.git
   cd prooflayer
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Create environment file**

   ```bash
   cp .env.example .env.local
   ```

4. **Configure environment variables** (see below)

5. **Run development server**

   ```bash
   npm run dev
   ```

   Open [http://localhost:3000](http://localhost:3000)

---

## Environment Variables

### Required (for production)

```env
# Bright Data Configuration
BRIGHT_DATA_API_TOKEN=your_api_token_here
BRIGHT_DATA_COLLECTOR_ID=c_your_collector_id_here

# LLM Configuration
LLM_API_KEY=your_llm_api_key_here
LLM_MODEL=gpt-4-turbo
LLM_API_ENDPOINT=https://api.openai.com/v1
```

### Optional

```env
# Application
NODE_ENV=development
NEXT_PUBLIC_API_URL=http://localhost:3000
```

### Getting Credentials

#### Bright Data

1. Sign up at [brightdata.com](https://brightdata.com)
2. Navigate to **Scraper Studio**
3. Create a custom collector (see instructions below)
4. Get API Token from **Account Settings → API Keys**
5. Get Collector ID from your published collector

#### LLM (OpenAI example)

1. Sign up at [openai.com](https://openai.com)
2. Navigate to **API Keys**
3. Create new secret key
4. Use the key in `LLM_API_KEY`

---

## Running Locally

### Development Mode

```bash
npm run dev
```

ProofLayer will automatically detect if Bright Data is not configured and use development mode with realistic mock data.

**Development mode is clearly labeled** and uses only for UI testing.

### Testing with Real Bright Data

Once you have:

1. Created a custom Bright Data collector
2. Set `BRIGHT_DATA_API_TOKEN` and `BRIGHT_DATA_COLLECTOR_ID`
3. Set `LLM_API_KEY` and LLM configuration

Run:

```bash
npm run dev
```

ProofLayer will use the real Bright Data scraper.

### Building for Production

```bash
npm run build
npm start
```

---

## Testing

### Test Claims

ProofLayer ships with test data for these topics:

1. **Renewable Energy** - "Solar energy capacity increased significantly between 2023 and 2025."
2. **Artificial Intelligence** - "AI language models have improved reasoning capabilities."
3. **Climate** - "Global temperatures have increased over the past century."

### Manual Testing

1. Start dev server: `npm run dev`
2. Enter a claim
3. Verify results
4. Check evidence matrix
5. Click source links to verify data

### Edge Cases to Test

- Empty claim
- Very long claim (>500 characters)
- Invalid URLs
- Claims with no available evidence
- Claims with conflicting sources
- Scraper failures (disconnect Bright Data)
- LLM API failures

---

## Architecture Decisions

### Why Next.js?

- Simplicity: React UI + Node.js backend in one framework
- API routes: Serverless functions for scraper and LLM calls
- Deployment: Easy on Vercel or other platforms
- Performance: Built-in optimization

### Why Bright Data?

- Reliability: Handles anti-bot, JavaScript, proxies
- Structured output: JSON we can process
- Custom scrapers: We control exactly what data is collected
- Transparency: Clear integration point

### Why TypeScript?

- Type safety: Catches errors early
- Documentation: Types serve as living documentation
- Refactoring: Easier to change code confidently

### Why Tailwind CSS?

- Utility-first: Quick, consistent styling
- No build complexity: Already included with Next.js
- Responsive: Mobile-first default
- Minimal CSS: No bloat

### Why No Database?

- Simplicity: Fewer moving parts
- Fast iteration: No schema migrations
- Hackathon timeline: Not needed for MVP

Future versions could add:

- User accounts and history
- Claim caching
- Evidence trends over time
- User feedback on verdict accuracy

---

## Limitations

### Current Scope

- **Single claim per request** - Could batch multiple claims
- **No authentication** - Could add user accounts
- **No caching** - Could cache scraper results
- **Limited sources** - Currently uses predefined source discovery
- **English only** - Could add language support
- **No evidence timeline** - Could visualize evidence chronologically

### Bright Data Limitations

- Rate limiting on API calls
- Scraper Studio has timeout limits
- Some websites may not be scrapable
- JavaScript rendering may fail on complex sites

### LLM Limitations

- API costs per request
- Rate limiting
- Model capability limits
- Hallucination risk (mitigated by evidence grounding)

---

## Future Improvements

### Phase 2

- Evidence timeline visualization
- Advanced source discovery (search APIs)
- Claim history and trending claims
- User accounts and saved verifications

### Phase 3

- Multi-language support
- Batch claim verification
- API for developers
- Browser extension
- Claim source comparison

### Phase 4

- ML-based source reliability scoring
- Temporal analysis (how verdicts change over time)
- Fact database for citation
- Integration with journalism platforms

---

## Responsible Data Usage

### Privacy

- No personal data is collected from users
- No tracking or analytics
- Claims are processed but not stored (unless implemented in future)
- Scraped data is used only for evidence analysis

### Web Scraping Ethics

- All scraped websites are public and unrestricted
- No login-protected or paywalled content
- Rate limits respected
- robots.txt honored
- No scraping of personal data

### Data Accuracy

- ProofLayer does not claim perfect accuracy
- Results are based on available evidence
- Confidence scores reflect evidence quality, not probability
- Users should verify critical claims independently

---

## AI Disclosure

**This project uses AI coding assistants (Claude) to accelerate development.**

Specifically:

- Architecture and design decisions
- Implementation of core components
- Testing and documentation
- Code review and refactoring

**However:**

- The team understands every component and technical decision
- The Bright Data integration is genuine and tested
- No part of the code is fabricated or hallucinated
- The LLM evidence analysis is real (production LLM calls, not mock)

This disclosure is in line with hackathon rules requiring transparency about AI coding assistant usage.

---

## Team

**Stack Overflowed**

Bright Data / WeMakeDevs Hackathon (August 17-23, 2026)

### Hackathon Rules Compliance

✅ Uses Bright Data Scraper Studio with custom scraper  
✅ Publicly available web data only  
✅ Main coding work started August 17  
✅ AI assistants disclosed  
✅ Team understands submitted code and architecture  
✅ Includes public source code repository  
✅ Clear README with example output  
✅ Demo video ready  
✅ Bright Data usage clearly explained  

---

## Support & Documentation

- **Official Bright Data Docs** - https://docs.brightdata.com/
- **Bright Data Scraper Studio** - https://docs.brightdata.com/datasets/scraper-studio/quickstart
- **Next.js Documentation** - https://nextjs.org/docs
- **Tailwind CSS** - https://tailwindcss.com/docs

---

## License

MIT

---

**Questions?** Feel free to reach out or file an issue.

**Live Demo** - [ProofLayer on Vercel]()

**Repository** - https://github.com/Stack-Overflowed/ProofLayer
